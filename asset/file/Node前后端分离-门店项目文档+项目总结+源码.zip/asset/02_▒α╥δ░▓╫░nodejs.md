# Nodejs 的安装与基本配置   

### 注意：文档中所有涉及到安装及环境变量配置相关的目录都要根据实际情况修改，本例中使用的目录为 /app/node

### 1、下载并解压最新的稳定版

	cd /opt
	wget http://nodejs.org/dist/v0.10.30/node-v0.10.30.tar.gz
	tar zxvf node-v0.10.30.tar.gz


### 2、编译安装
	
	cd /opt/node-v0.10.30
	./configure --prefix=/opt/IBM/app/node  # 根据实际情况修改
	make
	make install

安装结束后可以使用命令查看是否安装成功

	/opt/IBM/app/node/bin/node -v  # 根据实际情况修改
	
如果输出 v0.10.30 则安装成功。



### 3、添加环境变量

	vi /etc/profile


在最后添加以下几行并保存

	export NODE_ENV=prd # 该值需要根据实际情况设置(sit/pre/prd)，不设置则认为是dev环境
	export PM2_API_PORT=12306 # pm2监控API的端口，默认为9615，实际部署发现9615会冲突
	PATH=$PATH:/opt/IBM/app/node/bin  # 根据实际情况修改
	export PATH

然后刷新环境变量，使之立刻生效：
	
	source /etc/profile

### 4、npm 设置代理 
	
	export http_proxy=http://192.168.120.30:8080  # 设置终端代理
	npm config set proxy=http://192.168.120.30:8080
	npm config set registry=http://registry.npmjs.org


### 5、安装pm2模块

	npm install pm2@0.9.5 -g

安装结束后可以使用命令查看是否安装成功

	pm2 -v
	
如果输出 0.9.5 则安装成功

### 删除系统代理，否则不能连接内网机器

	export http_proxy=
	
### 开放80、3000、9615及12306端口
	
### node服务的启动与重启
pm2 kill  # 杀死进程
pm2 flush  # 清空日志
pm2 start /opt/IBM/web/storeFront/app.js -i max --name storeFront  # 启动集群
pm2 web  # 启动监控接口
