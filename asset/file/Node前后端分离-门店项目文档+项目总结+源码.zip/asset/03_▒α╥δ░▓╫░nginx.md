# Nginx 的安装与基本配置   


### 1、下载并解压最新的稳定版

	cd /opt
	wget http://nginx.org/download/nginx-1.6.1.tar.gz
	tar zxvf nginx-1.6.1.tar.gz

### 2、下载nginx的upstream_fair模块，用于负载均衡

	cd /opt
	wget https://github.com/gnosek/nginx-upstream-fair/archive/master.zip
	tar zxvf nginx-upstream-fair-master.zip
	
### 3、修改 Nginx 的版本信息

为了安全起见，我们一般不会暴露自己服务器的软件使用的什么版本，以防止出现针对特定版本的攻击。或者改成自己的信息，看起来更酷^_^。    


我们可以通过在编译前修改nginx源码的方式达到目的。文件位于：src/core/nginx.h


	#define NGINX_VERSION      "1.6.1"
	#define NGINX_VER          "nginx/" NGINX_VERSION

这里面可以修改为你想要的值。

安装完成的 Nginx 还有一种方法就是隐藏版本号：在 nginx.conf 的 http 内加上 server_tokens off;    

	http {
	......省略配置
	server_tokens off;
	.......省略配置
	}


### 4、编译安装
	
	cd /opt/nginx-1.7.2
	./configure --prefix=/app/nginx --with-pcre=/opt/pcre-8.34 --with-zlib=/opt/zlib-1.2.8 --with-http_stub_status_module --add-module=/opt/nginx-upstream-fair-master/ngx_http_upstream_fair_module.c
	make
	make install

### 5、添加用户

	adduser nginx
	
### 6、添加为服务

	cp nginx /etc/init.d/nginx
	chmod a+x /etc/init.d/nginx
	chkconfig --add ningx
	chkconfig --level nginx 2345 on
	service nginx start
