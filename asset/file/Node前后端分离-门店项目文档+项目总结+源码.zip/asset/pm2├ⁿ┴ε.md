# pm2 命令

pm2是一款强大的监控/守护程序，目前只支持linux环境安装。项目地址：https://github.com/Unitech/pm2


### 1、启动

	pm2 start /dir/app.js -i max  # 启动一个使用所有CPU核心的集群
	pm2 start /dir/app.js -i 4  # 手动指定集群个数
	pm2 start app.js --name myapp # 启动带有自定义名称的进程
	pm2 start app.js -i max -e /dir/err.log -o /dir/out.log  # 记录日志到文件


### 2、列出所有正在运行的进程

	pm2 list

### 3、杀死、重启某个或全部进程

	pm2 stop all # 停止所有进程
	pm2 stop 2   # 停止某个进程，该id可以通过 pm2 list 查看到
	pm2 stop myapp  # 停止某个进程，该名称是启动是设置的，可以通过 pm2 list 查看到

	pm2 restart all  # 重启所有进程
	pm2 restart 2   # 重启某个进程，该id可以通过 pm2 list 查看到
	pm2 restart myapp  # 重启某个进程，该名称是启动是设置的，可以通过 pm2 list 查看到

### 4、监控CPU及内存使用

	pm2 monit


### 5、为监控平台提供json格式数据

	pm2 web

此时使用 http://ip:9615 即可查看json格式输出的服务器信息


### 6、在终端中查看日志

	pm2 logs  # 显示所有进程的日志
	pm2 flush  # 清空日志
